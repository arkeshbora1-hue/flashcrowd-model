import math

import numpy as np
import pandas as pd
import pytest

from flashcrowd_engine import ForecastStore, LookAheadError, SimConfig, Simulator
from flashcrowd_engine.decision import allocate_budget, quantile, servers_for, service_level, survival
from flashcrowd_engine.grading import grade, pareto_front
from flashcrowd_engine.policies import AutopilotPolicy, OraclePolicy, Policy, ReactivePolicy, StaticPolicy

CAP = 1000.0


def cfg(**kw):
    base = dict(capacity_per_server=CAP, boot_steps=1, min_servers=1, max_servers=50, max_scale_up_per_step=50,
                initial_servers=2, cost_per_server_step=1.0, penalty_per_unserved=0.01)
    base.update(kw)
    return SimConfig(**base)


class Script(Policy):
    """Returns targets from a dict keyed by step; holds the current fleet otherwise."""
    name = "script"

    def __init__(self, plan):
        self.plan = plan

    def decide(self, obs):
        return self.plan.get(obs.step, obs.active + obs.booting)


def fc_frame(rows):
    return pd.DataFrame(rows, columns=["issued_at", "target_hour", "horizon", "p_surge", "q10", "q50", "q90", "q99"])


# ---------- demand accounting ----------

def test_served_plus_unserved_equals_demand():
    rng = np.random.default_rng(0)
    demand = rng.uniform(0, 6000, 200)
    res = Simulator(cfg()).run(demand, ReactivePolicy(0.1))
    f = res.frame
    assert np.allclose(f["served"] + f["unserved"], f["demand"])
    assert (f["served"] <= f["capacity"] + 1e-9).all()
    assert (f["unserved"] >= 0).all()
    assert np.allclose(f["capacity"], f["active"] * CAP)


def test_rejects_bad_demand():
    with pytest.raises(ValueError):
        Simulator(cfg()).run(np.array([1.0, -1.0]), StaticPolicy(1))
    with pytest.raises(ValueError):
        Simulator(cfg()).run(np.array([1.0, np.nan]), StaticPolicy(1))


# ---------- boot timing ----------

@pytest.mark.parametrize("boot", [0, 1, 2, 3])
def test_new_servers_serve_exactly_boot_steps_later(boot):
    demand = np.full(10, 100.0)
    res = Simulator(cfg(boot_steps=boot)).run(demand, Script({3: 5}))
    act = res.frame["active"].tolist()
    assert act[: 3] == [2, 2, 2]
    ready = 3 + boot
    assert act[ready] == 5
    assert all(a == 2 for a in act[3:ready])


def test_booting_servers_are_billed_but_do_not_serve():
    demand = np.array([0, 0, 5000, 5000, 5000.0])
    res = Simulator(cfg(boot_steps=2)).run(demand, Script({1: 5}))
    f = res.frame
    assert f["billed_servers"].iloc[1] == 5 and f["active"].iloc[1] == 2
    assert f["capacity"].iloc[2] == 2 * CAP                       # still booting at step 2
    assert f["unserved"].iloc[2] == 3000
    assert f["capacity"].iloc[3] == 5 * CAP                       # ready at 1 + 2


def test_scale_down_cancels_boots_first():
    res = Simulator(cfg(boot_steps=3)).run(np.full(6, 10.0), Script({0: 6, 1: 3}))
    f = res.frame
    assert f["active"].iloc[1] == 2 and f["booting"].iloc[1] == 1


# ---------- scaling limits ----------

def test_max_scale_up_per_step_and_bounds():
    c = cfg(max_scale_up_per_step=3, max_servers=8, min_servers=1, boot_steps=0)
    res = Simulator(c).run(np.full(6, 10.0), Script({0: 100, 1: 100, 2: 100, 3: 0}))
    act = res.frame["active"].tolist()
    assert act[0] == 5 and act[1] == 8 and act[2] == 8           # +3 per step, capped at 8
    assert act[3] == 1                                           # floor at min_servers
    assert (res.frame["launched"] <= 3).all()


# ---------- no look-ahead ----------

def test_policy_sees_only_past_demand():
    seen = []

    class Spy(Policy):
        name = "spy"

        def decide(self, obs):
            seen.append(len(obs.demand_history))
            return 1

    hist = np.ones(5)
    Simulator(cfg()).run(np.arange(10.0), Spy(), history=hist, start_hour=100)
    assert seen == [5 + i for i in range(10)]


def test_forecast_view_hides_future_issues():
    store = ForecastStore(fc_frame([(10, 11, 2, 0.1, 1, 2, 3, 4), (12, 13, 2, 0.9, 5, 6, 7, 8)]))
    v = store.view(11)
    assert v.latest(11) is not None and v.latest(13) is None
    with pytest.raises(LookAheadError):
        v.get(13, issued_at=12)
    assert len(v) == 1


def test_forecast_store_rejects_targets_before_issue():
    with pytest.raises(ValueError):
        ForecastStore(fc_frame([(10, 9, 1, 0.5, 1, 2, 3, 4)]))


def test_newest_issue_wins():
    store = ForecastStore(fc_frame([(10, 12, 3, 0.1, 1, 1, 1, 1), (11, 12, 2, 0.8, 9, 9, 9, 9)]))
    assert store.view(10).latest(12).p_surge == 0.1
    assert store.view(11).latest(12).p_surge == 0.8


def test_rewriting_future_forecasts_does_not_change_past_decisions():
    rng = np.random.default_rng(1)
    hours = np.arange(100, 140)
    rows = [(t, t + k - 1, k, 0.2, q, q * 1.5, q * 2, q * 3)
            for t in hours for k in (1, 2, 3) for q in [rng.uniform(1000, 8000)]]
    a = fc_frame(rows)
    b = a.copy()
    cut = 120
    late = b["issued_at"] > cut
    b.loc[late, ["q10", "q50", "q90", "q99"]] = rng.uniform(0, 50000, (late.sum(), 4))
    b.loc[late, ["q10", "q50", "q90", "q99"]] = np.sort(b.loc[late, ["q10", "q50", "q90", "q99"]].to_numpy(), 1)
    demand = rng.uniform(1000, 8000, len(hours))
    sim = Simulator(cfg())
    ra = sim.run(demand, AutopilotPolicy(0.9), ForecastStore(a), start_hour=100).frame
    rb = sim.run(demand, AutopilotPolicy(0.9), ForecastStore(b), start_hour=100).frame
    upto = ra["hour"] <= cut
    assert (ra.loc[upto, "target"].to_numpy() == rb.loc[upto, "target"].to_numpy()).all()


# ---------- decision ----------

def test_service_level_newsvendor():
    tau = service_level(cost_per_server_step=1.0, capacity_per_server=1000, penalty_per_unserved=0.009)
    assert tau == pytest.approx(0.9)


def test_quantile_interpolation_and_tails():
    q = {0.1: 100.0, 0.5: 200.0, 0.9: 400.0, 0.99: 1000.0}
    assert quantile(q, 0.5) == pytest.approx(200)
    assert quantile(q, 0.7) == pytest.approx(300)
    assert quantile(q, 0.995) > 1000
    xs = [quantile(q, t) for t in np.linspace(0, 1, 50)]
    assert all(b >= a for a, b in zip(xs, xs[1:]))
    assert survival(q, 200) == pytest.approx(0.5)
    assert servers_for(q, 0.9, 100) == 4


def test_allocate_budget_respects_cap_and_prefers_risk():
    big = {0.1: 4000.0, 0.5: 8000.0, 0.9: 15000.0, 0.99: 20000.0}
    small = {0.1: 500.0, 0.5: 900.0, 0.9: 1500.0, 0.99: 2000.0}
    alloc = allocate_budget({"a": big, "b": small}, budget=10, capacity_per_server=1000,
                            cost_per_server_step=1.0, penalty_per_unserved=0.01)
    assert sum(alloc.values()) <= 10
    assert alloc["a"] > alloc["b"] >= 1


# ---------- grading ----------

def test_grade_costs_by_hand():
    c = cfg(boot_steps=0, initial_servers=1, penalty_per_unserved=0.01)
    res = Simulator(c).run(np.array([500.0, 1500.0]), StaticPolicy(1))
    g = grade(res)
    assert g["server_cost"] == 2.0
    assert g["penalty_cost"] == pytest.approx(5.0)
    assert g["unserved_frac"] == pytest.approx(500 / 2000)
    assert g["sla_breach_hours"] == 1


def test_false_launch_is_counted():
    c = cfg(boot_steps=1)
    res = Simulator(c).run(np.full(8, 500.0), Script({1: 6}))
    g = grade(res)
    assert g["launch_events"] == 1 and g["false_launch_events"] == 1 and g["false_launch_servers"] == 4


def test_oracle_beats_reactive_on_a_spike():
    demand = np.r_[np.full(10, 1000.0), np.full(3, 9000.0), np.full(10, 1000.0)]
    c = cfg(boot_steps=1)
    o = grade(Simulator(c).run(demand, OraclePolicy(demand, 0)))
    r = grade(Simulator(c).run(demand, ReactivePolicy(0.2)))
    assert o["unserved_frac"] < r["unserved_frac"]


def test_pareto_front():
    pts = pd.DataFrame({"server_cost": [1, 2, 3, 2.5], "unserved_frac": [0.5, 0.2, 0.1, 0.3]})
    assert pareto_front(pts)["server_cost"].tolist() == [1, 2, 3]
