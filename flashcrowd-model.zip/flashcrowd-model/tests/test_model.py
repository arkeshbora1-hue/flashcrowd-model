import numpy as np
import pandas as pd
import pytest

from flashcrowd_model import config as C
from flashcrowd_model import features as F
from flashcrowd_model import leakcheck as LC
from flashcrowd_model import train as T
from flashcrowd_model.causes import HeuristicLabeler, add_cause_features
from flashcrowd_model.forecast_job import available_inputs
from flashcrowd_model.splits import make_splits, walk_forward
from flashcrowd_model.synth import SynthConfig, generate


@pytest.fixture(scope="module")
def raw():
    t = generate(SynthConfig(n_qids=15, days=11, stories=10, seed=3))
    return t["pages"], t["edits"], t["pageviews"]


def con_of(raw):
    return F.fresh_from_frames(*raw)


# ---------- labels ----------

def tiny(views):
    pages = pd.DataFrame({"page_id": [0], "qid": ["Q1"], "lang": ["en"], "region": ["us-east"]})
    pv = pd.DataFrame({"hour": np.arange(len(views)), "page_id": 0, "views": views})
    edits = pd.DataFrame({"ts": [0.5], "page_id": [0], "qid": ["Q1"], "lang": ["en"], "editor": ["a"],
                          "is_bot": [False]})
    con = F.fresh_from_frames(pages, edits, pv)
    F.run_sql(con, "labels.sql", k=C.SURGE_K, min_abs=C.SURGE_MIN_ABS, burn_in=C.BURN_IN, hour_end=len(views) - 1)
    return con.execute("SELECT hour, views, baseline_7d, surge FROM pv_labels ORDER BY hour").df()


def test_surge_definition():
    v = np.full(200, 100)
    v[180], v[190], v[195] = 400, 1000, 650
    lab = tiny(v).set_index("hour")
    assert lab.loc[100, "surge"] is None or pd.isna(lab.loc[100, "surge"])   # burn-in
    assert not lab.loc[180, "surge"]          # 4x but under the absolute floor (100 + 500)
    assert lab.loc[190, "surge"]              # 10x and +900
    assert lab.loc[195, "surge"]              # 6.5x and +550
    assert lab.loc[191, "baseline_7d"] == 100  # one spike does not move a 7-day median


def test_baseline_excludes_current_hour():
    v = np.full(200, 100)
    v[199] = 10_000
    lab = tiny(v).set_index("hour")
    assert lab.loc[199, "baseline_7d"] == 100


# ---------- leak checks ----------

def test_perturbation_check_passes(raw):
    rep = LC.perturbation_check(*raw, cut=230, seed=1)
    assert rep["passed"], rep


def test_perturbation_check_catches_a_real_leak(raw, monkeypatch):
    real = F.run_sql

    def leaky(con, name, **params):
        if name == "features.sql":
            params["lag"] = 0           # use pageviews from hour t-1: not yet published at t
        return real(con, name, **params)

    monkeypatch.setattr(F, "run_sql", leaky)
    rep = LC.perturbation_check(*raw, cut=230, seed=1)
    assert not rep["passed"]
    assert "pv_last" in rep["leaking_columns"]


def test_schema_and_splits(raw):
    frame = F.build(con_of(raw))
    assert LC.schema_check(frame)["passed"]
    assert LC.split_check(frame)["passed"]
    s = make_splits(frame["t"])
    assert s["train"][1] + C.EMBARGO < s["calib"][0] and s["calib"][1] + C.EMBARGO < s["test"][0]
    for (a, b), (c, d) in walk_forward(frame["t"]):
        assert b + C.EMBARGO < c


def test_train_refuses_when_leak_checks_fail(raw, monkeypatch):
    monkeypatch.setattr(T, "run_leakchecks", lambda con, n_cuts: {"passed": False})
    with pytest.raises(RuntimeError, match="leak checks failed"):
        T.train(con_of(raw))


# ---------- live == batch ----------

def test_live_matches_batch(raw):
    con = con_of(raw)
    batch = F.build(con)
    for t in (220, 240, 255):
        live = F.build(F.fresh_from_frames(*available_inputs(con, t)), t, t)
        b = batch[batch["t"] == t].sort_values("page_id").reset_index(drop=True)
        l = live.sort_values("page_id").reset_index(drop=True)
        cols = C.FEATURES + ["sbase_1", "sbase_2", "sbase_3"]
        pd.testing.assert_frame_equal(b[cols], l[cols], check_dtype=False)


def test_available_inputs_cut(raw):
    _, e, pv = available_inputs(con_of(raw), 230)
    assert e["ts"].max() < 230
    assert pv["hour"].max() == 230 - 1 - C.PAGEVIEW_LAG


# ---------- causes ----------

def test_heuristic_causes_use_issue_time_features_only(raw):
    frame = F.build(con_of(raw))
    out, cols = add_cause_features(frame, HeuristicLabeler())
    assert set(cols) <= set(out.columns)
    assert (out[cols].sum(axis=1) == 1).all()


# ---------- end to end ----------

def test_train_and_forecast_end_to_end(raw):
    con = con_of(raw)
    model, metrics = T.train(con, n_cuts=1)
    frame = F.build(con)
    t = int(frame["t"].max())
    art = model.article_forecasts(frame[frame["t"] == t])
    reg = model.region_forecasts(art, n_samples=200)
    assert (art["target_hour"] >= art["issued_at"]).all()
    assert art["p_surge"].between(0, 1).all()
    q = reg[["q10", "q50", "q90", "q99"]].to_numpy()
    assert (np.diff(q, axis=1) >= -1e-9).all()
    assert set(metrics["horizons"]) == set(C.HORIZONS)
