"""Turn probabilistic demand forecasts into server counts.

Single region: newsvendor. Provision capacity at the demand quantile
    tau = c_under / (c_under + c_over)
where c_under = penalty per unserved view and c_over = server cost per view of capacity.

Several regions sharing a launch budget: greedy marginal allocation (exact for this separable, concave
problem: each extra server's expected value only falls as a region gets more servers).
"""
from __future__ import annotations

import math

import numpy as np

TAIL_LEVELS = (0.0, 1.0)


def service_level(cost_per_server_step: float, capacity_per_server: float, penalty_per_unserved: float) -> float:
    c_over = cost_per_server_step / capacity_per_server
    c_under = penalty_per_unserved
    return c_under / (c_under + c_over)


def _knots(quantiles: dict[float, float]) -> tuple[np.ndarray, np.ndarray]:
    lv = np.array(sorted(quantiles), dtype=float)
    val = np.maximum.accumulate(np.array([quantiles[k] for k in lv], dtype=float))  # enforce monotone
    val = np.maximum(val, 0.0)
    # extend tails linearly: level 0 and level 1
    if len(lv) >= 2:
        lo_slope = (val[1] - val[0]) / (lv[1] - lv[0])
        hi_slope = (val[-1] - val[-2]) / (lv[-1] - lv[-2])
    else:
        lo_slope = hi_slope = 0.0
    lv = np.concatenate([[0.0], lv, [1.0]])
    val = np.concatenate([[max(0.0, val[0] - lo_slope * (lv[1]))], val, [val[-1] + hi_slope * (1 - lv[-2])]])
    return lv, val


def quantile(quantiles: dict[float, float], tau: float) -> float:
    """Demand at level ``tau`` by piecewise-linear interpolation between forecast quantiles."""
    lv, val = _knots(quantiles)
    return float(np.interp(np.clip(tau, 0.0, 1.0), lv, val))


def survival(quantiles: dict[float, float], x: float) -> float:
    """P(demand > x) under the same piecewise-linear distribution."""
    lv, val = _knots(quantiles)
    if x < val[0]:
        return 1.0
    if x >= val[-1]:
        return 0.0
    # val is non-decreasing; interpolate level at x on strictly increasing segments
    keep = np.concatenate([[True], np.diff(val) > 0])
    return float(1.0 - np.interp(x, val[keep], lv[keep]))


def servers_for(quantiles: dict[float, float], tau: float, capacity_per_server: float) -> int:
    return int(math.ceil(quantile(quantiles, tau) / capacity_per_server - 1e-9))


def allocate_budget(forecasts: dict[str, dict[float, float]], budget: int, capacity_per_server: float,
                    cost_per_server_step: float, penalty_per_unserved: float,
                    minimum: dict[str, int] | None = None) -> dict[str, int]:
    """Split at most ``budget`` servers across regions to maximise expected net value.

    Value of the n-th server in a region ~= penalty * capacity * P(D > (n - 0.5) * capacity) - server cost.
    A server is only added while that value is positive, so the budget is a cap, not a target.
    """
    alloc = {r: (minimum or {}).get(r, 0) for r in forecasts}
    used = sum(alloc.values())
    if used > budget:
        raise ValueError("minimum allocation exceeds budget")

    def gain(r: str) -> float:
        n = alloc[r] + 1
        return penalty_per_unserved * capacity_per_server * survival(forecasts[r], (n - 0.5) * capacity_per_server) \
            - cost_per_server_step

    while used < budget:
        best = max(forecasts, key=gain, default=None)
        if best is None or gain(best) <= 0:
            break
        alloc[best] += 1
        used += 1
    return alloc
