"""Scaling policies. Every policy sees only an Observation (past demand + forecasts issued so far)."""
from __future__ import annotations

import math

import numpy as np

from .decision import servers_for
from .sim import Observation


class Policy:
    name = "policy"

    def reset(self) -> None:
        pass

    def decide(self, obs: Observation) -> int:  # pragma: no cover - interface
        raise NotImplementedError


class StaticPolicy(Policy):
    """Fixed fleet size. Knob: n."""

    def __init__(self, n: int):
        self.n = n
        self.name = f"static(n={n})"

    def decide(self, obs: Observation) -> int:
        return self.n


class ReactivePolicy(Policy):
    """Classic autoscaler: size for last hour's demand plus headroom. Knob: headroom."""

    def __init__(self, headroom: float = 0.25):
        self.headroom = headroom
        self.name = f"reactive(h={headroom:g})"

    def decide(self, obs: Observation) -> int:
        if len(obs.demand_history) == 0:
            return obs.active
        last = obs.demand_history[-1]
        return math.ceil(last * (1 + self.headroom) / obs.config.capacity_per_server)


class AutopilotPolicy(Policy):
    """Forecast-driven: provision for the tau-quantile of demand over every bucket the fleet decision affects.

    Buckets t .. t+boot_steps are affected (scale-down is immediate; scale-up lands at t+boot_steps).
    Falls back to the reactive rule when no forecast exists for a bucket. Knob: tau.
    """

    def __init__(self, tau: float = 0.95, fallback_headroom: float = 0.25):
        self.tau = tau
        self.fallback = ReactivePolicy(fallback_headroom)
        self.name = f"autopilot(tau={tau:g})"

    def decide(self, obs: Observation) -> int:
        cap = obs.config.capacity_per_server
        need = []
        for target in range(obs.t, obs.t + obs.config.boot_steps + 1):
            f = obs.forecasts.latest(target)
            if f is not None:
                need.append(servers_for(f.quantiles, self.tau, cap))
        reactive = self.fallback.decide(obs)
        if not need:
            return reactive
        # never shrink below what last hour's real traffic needed (guard against a forecast miss)
        floor = math.ceil(obs.demand_history[-1] / cap) if len(obs.demand_history) else 0
        return max(max(need), floor)


class OraclePolicy(Policy):
    """Upper bound only: told the true future demand at construction. Never used for headline claims."""

    def __init__(self, demand: np.ndarray, start_hour: int):
        self._demand = np.asarray(demand, dtype=float)
        self._start = start_hour
        self.name = "oracle"

    def decide(self, obs: Observation) -> int:
        i = obs.t - self._start
        window = self._demand[i: i + obs.config.boot_steps + 1]
        return math.ceil(window.max() / obs.config.capacity_per_server)
