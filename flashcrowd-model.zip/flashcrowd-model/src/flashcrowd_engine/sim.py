"""Discrete-time capacity simulator: one step = one hour bucket.

Step order inside bucket t (see CONTRACTS.md §5):
  1. servers whose boot finished (ready_at <= t) become active
  2. the policy decides a target server count from an Observation (past demand + forecasts issued <= t)
  3. scaling limits are applied; new servers start booting (ready at t + boot_steps)
  4. demand[t] is served by ACTIVE servers only
  5. active + booting servers are billed
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .forecasts import ForecastStore, ForecastView


@dataclass(frozen=True)
class SimConfig:
    capacity_per_server: float = 5000.0   # views/hour one server can serve
    boot_steps: int = 1                   # hours from request to serving traffic
    min_servers: int = 1
    max_servers: int = 60
    max_scale_up_per_step: int = 12       # cloud API / quota limit on launches per hour
    initial_servers: int | None = None    # None: sized for demand[start-1]
    cost_per_server_step: float = 1.0     # cost of one server for one hour (booting servers are billed)
    penalty_per_unserved: float = 0.004   # cost of one unserved view (SLA / lost revenue)

    def __post_init__(self):
        if self.boot_steps < 0 or self.min_servers < 0 or self.max_servers < self.min_servers:
            raise ValueError("invalid SimConfig")


@dataclass(frozen=True)
class Observation:
    t: int                      # absolute hour of this decision
    step: int                   # index into the simulated window
    active: int
    booting: int
    demand_history: np.ndarray  # demand for buckets strictly before t (a copy)
    forecasts: ForecastView
    config: SimConfig


@dataclass
class SimResult:
    frame: pd.DataFrame
    config: SimConfig
    policy_name: str
    launches: list[tuple[int, int]] = field(default_factory=list)  # (hour, n_launched)


class Simulator:
    def __init__(self, config: SimConfig | None = None):
        self.cfg = config or SimConfig()

    def run(self, demand: np.ndarray, policy, forecasts: ForecastStore | None = None,
            start_hour: int = 0, history: np.ndarray | None = None) -> SimResult:
        """Simulate ``policy`` over ``demand`` (buckets start_hour .. start_hour+len-1).

        ``history`` is demand before ``start_hour`` (visible to policies as past data).
        """
        cfg = self.cfg
        demand = np.asarray(demand, dtype=float)
        if np.any(demand < 0) or not np.all(np.isfinite(demand)):
            raise ValueError("demand must be finite and non-negative")
        history = np.zeros(0) if history is None else np.asarray(history, dtype=float)
        store = forecasts or ForecastStore()
        full = np.concatenate([history, demand])
        off = len(history)

        if cfg.initial_servers is not None:
            active = cfg.initial_servers
        else:
            seed = history[-1] if len(history) else demand[0]
            active = int(np.ceil(seed / cfg.capacity_per_server))
        active = int(np.clip(active, cfg.min_servers, cfg.max_servers))
        booting: list[int] = []  # ready_at hour per booting server
        rows, launches = [], []
        policy.reset()

        for i in range(len(demand)):
            t = start_hour + i
            # 1. promote finished boots
            ready = sum(1 for r in booting if r <= t)
            booting = [r for r in booting if r > t]
            active += ready

            # 2. decide
            obs = Observation(t=t, step=i, active=active, booting=len(booting),
                              demand_history=full[: off + i].copy(), forecasts=store.view(t), config=cfg)
            target = int(policy.decide(obs))

            # 3. apply limits
            target = int(np.clip(target, cfg.min_servers, cfg.max_servers))
            total = active + len(booting)
            launched = 0
            if target > total:
                launched = min(target - total, cfg.max_scale_up_per_step)
                booting += [t + cfg.boot_steps] * launched
                launches.append((t, launched))
            elif target < total:
                drop = total - target
                cancel = min(drop, len(booting))            # cancel newest boots first
                booting = sorted(booting)[: len(booting) - cancel]
                active -= drop - cancel
            if cfg.boot_steps == 0:                         # instant boot serves this bucket
                active += len(booting)
                booting = []

            # 4. serve
            capacity = active * cfg.capacity_per_server
            served = min(demand[i], capacity)
            unserved = demand[i] - served
            # 5. bill
            billed = active + len(booting)
            rows.append((t, demand[i], capacity, served, unserved, active, len(booting), billed, target,
                         launched))

        frame = pd.DataFrame(rows, columns=["hour", "demand", "capacity", "served", "unserved", "active",
                                            "booting", "billed_servers", "target", "launched"])
        return SimResult(frame=frame, config=cfg, policy_name=policy.name, launches=launches)
