"""Forecast storage with a hard no-look-ahead guarantee.

A policy never receives the full store. At step ``t`` it receives a ``ForecastView`` that is *built from*
rows with ``issued_at <= t``; later rows do not exist inside the view, so no attribute access can leak them.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

QUANTILE_COLS = ("q10", "q50", "q90", "q99")
QUANTILE_LEVELS = (0.10, 0.50, 0.90, 0.99)
REQUIRED = ("issued_at", "target_hour", "horizon", "p_surge") + QUANTILE_COLS


class LookAheadError(RuntimeError):
    """Raised when code asks for information that was not available at decision time."""


@dataclass(frozen=True)
class Forecast:
    issued_at: int
    target_hour: int
    horizon: int
    p_surge: float
    quantiles: dict[float, float]


class ForecastView:
    """Read-only window onto forecasts issued at or before ``now``."""

    __slots__ = ("_now", "_rows")

    def __init__(self, rows: dict[int, Forecast], now: int):
        self._now = now
        self._rows = rows  # keyed by target_hour, only rows with issued_at <= now

    @property
    def now(self) -> int:
        return self._now

    def latest(self, target_hour: int) -> Forecast | None:
        """Most recent forecast for ``target_hour`` issued at or before now (None if none)."""
        return self._rows.get(target_hour)

    def get(self, target_hour: int, issued_at: int) -> Forecast | None:
        if issued_at > self._now:
            raise LookAheadError(f"forecast issued at {issued_at} requested at t={self._now}")
        f = self._rows.get(target_hour)
        return f if f is not None and f.issued_at == issued_at else None

    def __len__(self) -> int:
        return len(self._rows)


class ForecastStore:
    """All forecasts for ONE region (or one page). Hands out time-restricted views."""

    def __init__(self, df: pd.DataFrame | None = None):
        if df is None or len(df) == 0:
            self._issued = np.array([], dtype=np.int64)
            self._records: list[Forecast] = []
            return
        missing = [c for c in REQUIRED if c not in df.columns]
        if missing:
            raise ValueError(f"forecast frame missing columns: {missing}")
        bad = df[df["target_hour"] < df["issued_at"]]
        if len(bad):
            raise ValueError(f"{len(bad)} forecasts target an hour before they were issued")
        df = df.sort_values(["issued_at", "horizon"]).reset_index(drop=True)
        self._issued = df["issued_at"].to_numpy(np.int64)
        self._records = [
            Forecast(int(r.issued_at), int(r.target_hour), int(r.horizon), float(r.p_surge),
                     {lv: float(getattr(r, c)) for lv, c in zip(QUANTILE_LEVELS, QUANTILE_COLS)})
            for r in df.itertuples(index=False)
        ]

    @classmethod
    def from_frame(cls, df: pd.DataFrame, region: str) -> "ForecastStore":
        return cls(df[df["region"] == region])

    def view(self, now: int) -> ForecastView:
        """Forecasts visible at ``now``: newest issue wins per target hour."""
        n = int(np.searchsorted(self._issued, now, side="right"))
        rows: dict[int, Forecast] = {}
        for f in self._records[:n]:  # ascending issue time, so later issues overwrite earlier ones
            rows[f.target_hour] = f
        return ForecastView(rows, now)
