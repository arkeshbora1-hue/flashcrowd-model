"""Score simulator runs and forecasts. Failure metrics are reported next to success metrics, always."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

from .sim import SimResult


def grade(res: SimResult, sla_unserved_frac: float = 0.01, false_window: int = 2) -> dict:
    f, cfg = res.frame, res.config
    server_cost = float(f["billed_servers"].sum() * cfg.cost_per_server_step)
    unserved = float(f["unserved"].sum())
    penalty = unserved * cfg.penalty_per_unserved
    demand = float(f["demand"].sum())
    breach = (f["unserved"] > sla_unserved_frac * f["demand"]).sum()
    idle_server_hours = float(((f["capacity"] - f["served"]) / cfg.capacity_per_server).sum())

    # A launch is "false" if, once those servers are ready, demand never needs them within the window.
    hour_idx = {h: i for i, h in enumerate(f["hour"])}
    false_launches, false_servers = 0, 0
    for hour, n in res.launches:
        i = hour_idx[hour]
        before = f["active"].iat[i] + f["booting"].iat[i] - n          # fleet before the launch
        lo = i + cfg.boot_steps
        window = f["demand"].iloc[lo: lo + false_window + 1]
        if len(window) and window.max() <= before * cfg.capacity_per_server:
            false_launches += 1
            false_servers += n
    return {
        "policy": res.policy_name,
        "total_cost": server_cost + penalty,
        "server_cost": server_cost,
        "penalty_cost": penalty,
        "unserved_frac": unserved / demand if demand else 0.0,
        "sla_breach_hours": int(breach),
        "idle_server_hours": idle_server_hours,
        "launch_events": len(res.launches),
        "false_launch_events": false_launches,
        "false_launch_rate": false_launches / len(res.launches) if res.launches else 0.0,
        "false_launch_servers": false_servers,
    }


def forecast_metrics(y_true: np.ndarray, p: np.ndarray) -> dict:
    y_true, p = np.asarray(y_true).astype(int), np.asarray(p, dtype=float)
    out = {"n": int(len(y_true)), "positives": int(y_true.sum()), "brier": float(brier_score_loss(y_true, p))}
    if 0 < y_true.sum() < len(y_true):
        out["pr_auc"] = float(average_precision_score(y_true, p))
        out["roc_auc"] = float(roc_auc_score(y_true, p))
        out["base_rate"] = float(y_true.mean())
    return out


def lead_time(forecasts: pd.DataFrame, surge_onsets: pd.DataFrame, threshold: float, boot_steps: int) -> dict:
    """For each surge onset (page, hour), the earliest issue time with p_surge >= threshold for that hour.

    forecasts: page_id, issued_at, target_hour, p_surge. surge_onsets: page_id, hour.
    lead = onset_hour - issued_at (hours of warning before the surging bucket starts).
    """
    hit = forecasts[forecasts["p_surge"] >= threshold]
    m = surge_onsets.merge(hit, left_on=["page_id", "hour"], right_on=["page_id", "target_hour"], how="left")
    first = m.groupby(["page_id", "hour"])["issued_at"].min().reset_index()
    lead = (first["hour"] - first["issued_at"]).astype(float)
    detected = lead.notna()
    n = len(first)
    return {
        "onsets": int(n),
        "detected_frac": float(detected.mean()) if n else 0.0,
        "mean_lead_h": float(lead[detected].mean()) if detected.any() else 0.0,
        "warned_before_boot_frac": float((lead >= boot_steps).mean()) if n else 0.0,
    }


def pareto_front(points: pd.DataFrame, x: str = "server_cost", y: str = "unserved_frac") -> pd.DataFrame:
    pts = points.sort_values([x, y]).reset_index(drop=True)
    best, keep = np.inf, []
    for i, v in enumerate(pts[y]):
        if v < best:
            best = v
            keep.append(i)
    return pts.iloc[keep]
