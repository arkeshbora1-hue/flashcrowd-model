"""The trained forecast bundle: per-horizon surge classifier + isotonic calibrator + surge-size quantiles."""
from __future__ import annotations

import pickle
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import config as C
from .causes import add_cause_features, get_labeler
from .features import horizon_frame

SIZE_LEVELS = (0.1, 0.5, 0.9)


@dataclass
class HorizonModel:
    clf: object
    calibrator: object
    size: dict          # level -> LGBMRegressor on z = log1p(views) - log1p(sbase), surge rows only


@dataclass
class ForecastModel:
    version: str
    features: list[str]
    horizons: dict[int, HorizonModel]
    nonsurge_levels: np.ndarray        # empirical quantiles of z on non-surge rows
    nonsurge_z: np.ndarray
    causes: str = "none"
    meta: dict = field(default_factory=dict)

    # ---------- inference ----------
    def _prep(self, frame: pd.DataFrame) -> pd.DataFrame:
        frame, _ = add_cause_features(frame, get_labeler(self.causes))
        return frame

    def p_surge(self, hf: pd.DataFrame, k: int) -> np.ndarray:
        hm = self.horizons[k]
        raw = hm.clf.predict_proba(hf[self.features])[:, 1]
        return hm.calibrator.predict(raw)

    def article_forecasts(self, frame: pd.DataFrame) -> pd.DataFrame:
        frame = self._prep(frame)
        outs = []
        for k in self.horizons:
            hf = horizon_frame(frame, k)
            hf["sbase"] = hf["sbase"].fillna(hf["pv_last"]).fillna(0.0)
            hf["log_sbase"] = np.log1p(hf["sbase"])
            p = self.p_surge(hf, k)
            zq = np.column_stack([self.horizons[k].size[lv].predict(hf[self.features]) for lv in SIZE_LEVELS])
            zq = np.maximum.accumulate(zq, axis=1)
            sizes = np.expm1(hf["log_sbase"].to_numpy()[:, None] + zq)
            outs.append(pd.DataFrame({
                "page_id": hf["page_id"].to_numpy(), "qid": hf["qid"].to_numpy(), "lang": hf["lang"].to_numpy(),
                "region": hf["region"].to_numpy(), "issued_at": hf["t"].to_numpy(),
                "target_hour": hf["target_hour"].to_numpy(), "horizon": k, "p_surge": p,
                "base_views": hf["sbase"].to_numpy(),
                "size_q10": sizes[:, 0], "size_q50": sizes[:, 1], "size_q90": sizes[:, 2],
                "z_q10": zq[:, 0], "z_q50": zq[:, 1], "z_q90": zq[:, 2],
                "cause_label": None, "model_version": self.version}))
        out = pd.concat(outs, ignore_index=True)
        assert (out["target_hour"] >= out["issued_at"]).all()
        return out

    def region_forecasts(self, art: pd.DataFrame, n_samples: int = 400, seed: int = C.SEED) -> pd.DataFrame:
        """Monte Carlo over pages: each page surges with p_surge (size from its quantiles) or follows the
        non-surge residual distribution; regional demand = sum of page views."""
        rng = np.random.default_rng(seed)
        rows = []
        lv = np.array([0.0, 0.1, 0.5, 0.9, 1.0])
        for (region, t, k), g in art.groupby(["region", "issued_at", "horizon"], sort=True):
            n = len(g)
            zq = g[["z_q10", "z_q50", "z_q90"]].to_numpy()
            lo = zq[:, 0] - (zq[:, 1] - zq[:, 0]) / 0.4 * 0.1
            hi = zq[:, 2] + (zq[:, 2] - zq[:, 1]) / 0.4 * 0.1
            knots = np.column_stack([lo, zq, hi])                           # (n, 5)
            u = rng.random((n, n_samples))
            idx = np.clip(np.searchsorted(lv, u, side="right") - 1, 0, 3)
            l0, l1 = lv[idx], lv[idx + 1]
            v0 = np.take_along_axis(knots, idx, 1)
            v1 = np.take_along_axis(knots, idx + 1, 1)
            z_surge = v0 + (v1 - v0) * (u - l0) / (l1 - l0)
            z_calm = np.interp(rng.random((n, n_samples)), self.nonsurge_levels, self.nonsurge_z)
            surge = rng.random((n, n_samples)) < g["p_surge"].to_numpy()[:, None]
            logb = np.log1p(g["base_views"].to_numpy())[:, None]
            total = np.expm1(logb + np.where(surge, z_surge, z_calm)).clip(min=0).sum(0)
            thresh = C.REGION_SURGE_MULT * g["base_views"].sum()
            q = np.quantile(total, [0.1, 0.5, 0.9, 0.99])
            rows.append((region, int(t), int(t) + int(k) - 1, int(k), float((total > thresh).mean()), *q,
                         float(thresh), self.version))
        return pd.DataFrame(rows, columns=["region", "issued_at", "target_hour", "horizon", "p_surge", "q10", "q50",
                                           "q90", "q99", "surge_threshold", "model_version"])

    # ---------- io ----------
    def save(self, path=C.MODEL_DIR / "forecast_model.pkl"):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as fh:
            pickle.dump(self, fh)
        return path

    @staticmethod
    def load(path=C.MODEL_DIR / "forecast_model.pkl") -> "ForecastModel":
        with open(path, "rb") as fh:
            return pickle.load(fh)
