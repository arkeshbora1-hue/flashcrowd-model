"""Synthetic Wikipedia-like data so PC3 can build without PC1's Snowflake extract.

What it simulates (each one exists to test a real failure mode):
  * news stories: clusters of related articles surge together, edits lead views by 0-4 h
    (25% of stories are "silent": views move first, edits follow)
  * hard negatives: multi-editor activity that only lifts views ~1.5x
  * edit wars: 2 editors, dozens of edits, no traffic change
  * bot bursts: one bot, dozens of edits flagged is_bot, no traffic change
Output tables match CONTRACTS.md §3.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass

import duckdb
import numpy as np
import pandas as pd

from . import config as C

TZ = {"en": -5, "de": 1, "fr": 1, "es": -4, "pt": -3, "ja": 9}


@dataclass
class SynthConfig:
    n_qids: int = 120
    days: int = 42
    stories: int = 70            # news stories over the whole period
    qids_per_story: tuple = (1, 6)
    solo_events_per_qid: float = 0.6
    hard_negatives_per_qid: float = 0.6
    edit_wars_per_qid: float = 1.0
    bot_bursts_per_qid: float = 1.5
    background_edit_rate: float = 0.03   # human edits per page per hour
    seed: int = C.SEED


def generate(cfg: SynthConfig = SynthConfig()) -> dict[str, pd.DataFrame]:
    rng = np.random.default_rng(cfg.seed)
    H = cfg.days * 24
    langs = list(C.LANG_REGION)

    # ---- pages
    rows = []
    for q in range(cfg.n_qids):
        chosen = [l for l in langs if rng.random() < (0.85 if l == "en" else 0.35)] or ["en"]
        for l in chosen:
            rows.append((f"Q{1000 + q}", l, C.LANG_REGION[l]))
    pages = pd.DataFrame(rows, columns=["qid", "lang", "region"])
    pages.insert(0, "page_id", np.arange(len(pages)))
    P = len(pages)
    qid_pages = pages.groupby("qid")["page_id"].apply(np.array).to_dict()
    page_lang = pages["lang"].to_numpy()

    # ---- baseline views: level x diurnal x weekly
    level = rng.lognormal(5.3, 0.9, P)
    hours = np.arange(H)
    local = (hours[None, :] + np.array([TZ[l] for l in page_lang])[:, None]) % 24
    diurnal = 1 + 0.45 * np.sin(2 * np.pi * (local - 9) / 24)
    dow = (hours // 24) % 7
    weekly = np.where(dow >= 5, 0.88, 1.0)[None, :]
    mult = np.ones((P, H))

    editors_pool = np.array([f"user{i}" for i in range(6000)])
    edits: list[tuple] = []
    next_new_editor = [0]

    def new_editors(n):
        start = next_new_editor[0]
        next_new_editor[0] += n
        return [f"newcomer{start + i}" for i in range(n)]

    def add_surge(page_ids, onset, lead, peak, tau, edit_rate, rise_from_edits=True):
        for p in page_ids:
            j = np.arange(H - onset)
            mult[p, onset:] *= 1 + (peak - 1) * np.exp(-j / tau)
            # edits: start `lead` hours before onset, run ~5 h past it, from many distinct newcomers
            start = onset - lead
            for h in range(max(0, start), min(H, onset + 5)):
                n = rng.poisson(edit_rate)
                if n:
                    names = new_editors(max(1, int(n * 0.8)))
                    for _ in range(n):
                        edits.append((h + rng.random(), p, rng.choice(names), False))

    # news stories: several related qids surge within an hour of each other
    lo, hi = C.BURN_IN + 12, H - 8
    for _ in range(cfg.stories):
        onset = int(rng.integers(lo, hi))
        k = int(rng.integers(*cfg.qids_per_story))
        silent = rng.random() < 0.25
        for q in rng.choice(cfg.n_qids, size=k, replace=False):
            ps = [p for p in qid_pages[f"Q{1000 + q}"] if rng.random() < 0.75] or list(qid_pages[f"Q{1000 + q}"][:1])
            o = onset + int(rng.integers(0, 2))
            lead = 0 if silent else int(rng.integers(1, 5))
            add_surge(ps, o, lead, peak=float(np.exp(rng.uniform(np.log(5), np.log(50)))),
                      tau=float(rng.uniform(2, 7)), edit_rate=float(rng.uniform(3, 9)))

    for q in range(cfg.n_qids):
        ps = qid_pages[f"Q{1000 + q}"]
        for _ in range(rng.poisson(cfg.solo_events_per_qid)):            # one-article surges
            onset = int(rng.integers(lo, hi))
            add_surge(ps[: rng.integers(1, len(ps) + 1)], onset, int(rng.integers(0, 4)),
                      peak=float(np.exp(rng.uniform(np.log(4), np.log(30)))), tau=float(rng.uniform(2, 6)),
                      edit_rate=float(rng.uniform(2, 7)))
        for _ in range(rng.poisson(cfg.hard_negatives_per_qid)):          # busy editing, mild interest
            onset = int(rng.integers(lo, hi))
            add_surge(ps[:1], onset, int(rng.integers(1, 4)), peak=1.5, tau=3.0, edit_rate=float(rng.uniform(2, 6)))
        for _ in range(rng.poisson(cfg.edit_wars_per_qid)):               # edit war: 2 editors, no traffic
            p = int(rng.choice(ps))
            h0 = int(rng.integers(0, H - 4))
            pair = rng.choice(editors_pool, 2, replace=False)
            for h in range(h0, h0 + 3):
                for _ in range(rng.poisson(12)):
                    edits.append((h + rng.random(), p, rng.choice(pair), False))
        for _ in range(rng.poisson(cfg.bot_bursts_per_qid)):              # bot burst: flagged, no traffic
            p = int(rng.choice(ps))
            h0 = int(rng.integers(0, H - 2))
            bot = f"Bot{rng.integers(0, 20)}"
            for _ in range(rng.integers(20, 80)):
                edits.append((h0 + 2 * rng.random(), p, bot, True))

    # background human edits
    n_bg = rng.poisson(cfg.background_edit_rate * P * H)
    for ts, p, e in zip(rng.uniform(0, H, n_bg), rng.integers(0, P, n_bg), rng.choice(editors_pool, n_bg)):
        edits.append((float(ts), int(p), e, False))

    lam = level[:, None] * diurnal * weekly * mult
    views = rng.poisson(lam)
    pv = pd.DataFrame({"hour": np.tile(hours, P), "page_id": np.repeat(np.arange(P), H),
                       "views": views.ravel().astype(np.int64)})

    ed = pd.DataFrame(edits, columns=["ts", "page_id", "editor", "is_bot"])
    ed = ed[(ed["ts"] >= 0) & (ed["ts"] < H)]
    ed = ed.merge(pages[["page_id", "qid", "lang"]], on="page_id")[["ts", "page_id", "qid", "lang", "editor", "is_bot"]]
    ed = ed.sort_values("ts").reset_index(drop=True)
    return {"pages": pages, "edits": ed, "pageviews": pv}


def write_db(tables: dict[str, pd.DataFrame], path=C.DB_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(path))
    for name, df in tables.items():
        con.register("tmp_df", df)
        con.execute(f"CREATE OR REPLACE TABLE {name} AS SELECT * FROM tmp_df")
        con.unregister("tmp_df")
    con.close()


def main(argv=None):
    ap = argparse.ArgumentParser(description="Generate synthetic FLASHCROWD data")
    ap.add_argument("--qids", type=int, default=SynthConfig.n_qids)
    ap.add_argument("--days", type=int, default=SynthConfig.days)
    ap.add_argument("--seed", type=int, default=C.SEED)
    a = ap.parse_args(argv)
    t = generate(SynthConfig(n_qids=a.qids, days=a.days, seed=a.seed))
    write_db(t)
    print({k: len(v) for k, v in t.items()}, "->", C.DB_PATH)


if __name__ == "__main__":
    main()
