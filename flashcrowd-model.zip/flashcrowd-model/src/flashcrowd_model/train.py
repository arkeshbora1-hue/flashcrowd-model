"""Train 1/2/3-hour surge classifiers + surge-size quantile models with walk-forward validation.

Refuses to run unless the leak checks pass. Calibration uses the calib window; test is touched once.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression

from . import config as C
from . import features as F
from .causes import add_cause_features, get_labeler
from .leakcheck import run_all as run_leakchecks
from .model import SIZE_LEVELS, ForecastModel, HorizonModel
from .splits import make_splits, mask, walk_forward

from flashcrowd_engine.grading import forecast_metrics


def _clf():
    return lgb.LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=31, min_child_samples=40,
                              subsample=0.8, subsample_freq=1, colsample_bytree=0.8, reg_lambda=1.0,
                              random_state=C.SEED, verbose=-1)


def _qreg(alpha):
    return lgb.LGBMRegressor(objective="quantile", alpha=alpha, n_estimators=200, learning_rate=0.05,
                             num_leaves=15, min_child_samples=20, random_state=C.SEED, verbose=-1)


def _prep(frame: pd.DataFrame, k: int) -> pd.DataFrame:
    hf = F.horizon_frame(frame, k)
    hf = hf[hf["y"].notna()].copy()
    hf["sbase"] = hf["sbase"].fillna(hf["pv_last"]).fillna(0.0)
    hf["log_sbase"] = np.log1p(hf["sbase"])
    hf["z"] = np.log1p(hf["views_target"]) - hf["log_sbase"]
    return hf


def train(con, causes: str = "none", skip_leakcheck: bool = False, n_cuts: int = 2) -> tuple[ForecastModel, dict]:
    if not skip_leakcheck:
        rep = run_leakchecks(con, n_cuts=n_cuts)
        if not rep["passed"]:
            raise RuntimeError("leak checks failed; refusing to train. See out/leakcheck.json")
    frame = F.build(con)
    frame, cause_cols = add_cause_features(frame, get_labeler(causes))
    feats = C.FEATURES + C.HORIZON_FEATURES + cause_cols
    splits = make_splits(frame["t"])
    metrics: dict = {"splits": splits, "causes": causes, "features": feats, "horizons": {}}
    horizons: dict[int, HorizonModel] = {}
    calm_z = []

    for k in C.HORIZONS:
        hf = _prep(frame, k)
        tr, ca, te = (hf[mask(hf, splits[s])] for s in ("train", "calib", "test"))

        # walk-forward CV inside train+calib (never touches test)
        dev = hf[hf["t"] <= splits["calib"][1]]
        cv = []
        for (a, b), (c, d) in walk_forward(dev["t"]):
            fit, val = dev[dev["t"].between(a, b)], dev[dev["t"].between(c, d)]
            m = _clf().fit(fit[feats], fit["y"])
            cv.append({"valid": [c, d], "model": forecast_metrics(val["y"], m.predict_proba(val[feats])[:, 1]),
                       "persistence": forecast_metrics(val["y"], val["surge_last"])})

        clf = _clf().fit(tr[feats], tr["y"])
        iso = IsotonicRegression(out_of_bounds="clip", y_min=0, y_max=1)
        iso.fit(clf.predict_proba(ca[feats])[:, 1], ca["y"])
        p_test = iso.predict(clf.predict_proba(te[feats])[:, 1])

        surge_tr = tr[tr["y"] == 1]
        size = {lv: _qreg(lv).fit(surge_tr[feats], surge_tr["z"]) for lv in SIZE_LEVELS}
        st = te[te["y"] == 1]
        cover = {}
        if len(st):
            pred = {lv: size[lv].predict(st[feats]) for lv in SIZE_LEVELS}
            cover = {f"q{int(lv * 100)}_coverage": float((st["z"] <= pred[lv]).mean()) for lv in SIZE_LEVELS}

        calm_z.append(tr.loc[tr["y"] == 0, "z"].to_numpy())
        horizons[k] = HorizonModel(clf=clf, calibrator=iso, size=size)
        metrics["horizons"][k] = {
            "walk_forward": cv,
            "test": {"model": forecast_metrics(te["y"], p_test),
                     "persistence": forecast_metrics(te["y"], te["surge_last"]),
                     "size_quantile_coverage": cover},
        }

    levels = np.linspace(0.005, 0.995, 100)
    calm = np.concatenate(calm_z)
    model = ForecastModel(
        version=f"fc-{dt.date.today().isoformat()}-{causes}", features=feats, horizons=horizons,
        nonsurge_levels=levels, nonsurge_z=np.quantile(calm, levels), causes=causes,
        meta={"data_fingerprint": F.fingerprint(con), "seed": C.SEED, "splits": splits})
    metrics["model_version"] = model.version
    metrics["data_fingerprint"] = model.meta["data_fingerprint"]
    return model, metrics


def main(argv=None):
    ap = argparse.ArgumentParser(description="Train FLASHCROWD surge forecasters")
    ap.add_argument("--causes", choices=["none", "heuristic", "gemini"], default="none")
    a = ap.parse_args(argv)
    con = F.connect()
    model, metrics = train(con, a.causes)
    suffix = "" if a.causes == "none" else f"_{a.causes}"
    path = model.save(C.MODEL_DIR / f"forecast_model{suffix}.pkl")
    C.OUT_DIR.mkdir(exist_ok=True)
    (C.OUT_DIR / f"train_metrics{suffix}.json").write_text(json.dumps(metrics, indent=2, default=str))
    for k, m in metrics["horizons"].items():
        t = m["test"]
        print(f"h={k}: PR-AUC model {t['model'].get('pr_auc', float('nan')):.3f} vs persistence "
              f"{t['persistence'].get('pr_auc', float('nan')):.3f} | Brier {t['model']['brier']:.4f} vs "
              f"{t['persistence']['brier']:.4f}")
    print("saved", path)


if __name__ == "__main__":
    main()
