"""Write article + regional forecasts using only data available at issue time (CONTRACTS §4).

  live:  flashcrowd-forecast --issue-time 900      raw data is FILTERED by availability before any SQL runs
  batch: flashcrowd-forecast --range 760 1007      same SQL + model over many issue hours (backtests);
                                                   proven equal to live by tests/test_model.py::test_live_matches_batch
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from . import config as C
from . import features as F
from .model import ForecastModel

FC_DIR = C.OUT_DIR / "forecasts"


def available_inputs(con, issue_time: int):
    """Raw tables cut to what existed at ``issue_time``."""
    pages, edits, pv = F.raw_tables(con)
    edits = edits[edits["ts"] < issue_time]
    pv = pv[pv["hour"] <= issue_time - 1 - C.PAGEVIEW_LAG]
    assert edits["ts"].max() < issue_time
    assert pv["hour"].max() + 1 + C.PAGEVIEW_LAG <= issue_time
    return pages, edits, pv


def live(con, model: ForecastModel, issue_time: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    lcon = F.fresh_from_frames(*available_inputs(con, issue_time))
    frame = F.build(lcon, issue_time, issue_time)
    art = model.article_forecasts(frame)
    reg = model.region_forecasts(art)
    _check(art, reg)
    return art, reg


def batch(con, model: ForecastModel, t_min: int, t_max: int, frame: pd.DataFrame | None = None):
    frame = F.build(con) if frame is None else frame
    frame = frame[frame["t"].between(t_min, t_max)]
    art = model.article_forecasts(frame)
    reg = model.region_forecasts(art)
    _check(art, reg)
    return art, reg


def _check(art: pd.DataFrame, reg: pd.DataFrame) -> None:
    for df in (art, reg):
        assert (df["target_hour"] >= df["issued_at"]).all(), "forecast targets an hour before issue"
        assert df["p_surge"].between(0, 1).all()
    q = reg[["q10", "q50", "q90", "q99"]].to_numpy()
    assert (q[:, 1:] >= q[:, :-1] - 1e-9).all(), "regional quantiles not monotone"


def write(art: pd.DataFrame, reg: pd.DataFrame, tag: str, out_dir: Path = FC_DIR) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    a, r = out_dir / f"article_forecasts_{tag}.parquet", out_dir / f"region_forecasts_{tag}.parquet"
    art.drop(columns=["z_q10", "z_q50", "z_q90"]).to_parquet(a, index=False)
    reg.to_parquet(r, index=False)
    return a, r


def main(argv=None):
    ap = argparse.ArgumentParser(description="Issue FLASHCROWD forecasts")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--issue-time", type=int, help="issue hour t (live mode)")
    g.add_argument("--range", nargs=2, type=int, metavar=("T_MIN", "T_MAX"), help="batch over issue hours")
    ap.add_argument("--model", default=str(C.MODEL_DIR / "forecast_model.pkl"))
    a = ap.parse_args(argv)
    con, model = F.connect(), ForecastModel.load(Path(a.model))
    if a.issue_time is not None:
        art, reg = live(con, model, a.issue_time)
        paths = write(art, reg, f"t{a.issue_time}")
    else:
        art, reg = batch(con, model, *a.range)
        paths = write(art, reg, f"{a.range[0]}_{a.range[1]}")
    print(f"{len(art)} article rows, {len(reg)} region rows ->", *paths)


if __name__ == "__main__":
    main()
