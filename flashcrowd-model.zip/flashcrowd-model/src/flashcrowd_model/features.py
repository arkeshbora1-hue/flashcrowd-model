"""Run the label + feature SQL. The same SQL serves training, backtest and the live forecast job."""
from __future__ import annotations

import hashlib

import duckdb
import pandas as pd

from . import config as C


def _sql(name: str, **params) -> str:
    return (C.SQL_DIR / name).read_text().format(**params)


def run_sql(con: duckdb.DuckDBPyConnection, name: str, **params) -> None:
    text = "\n".join(l.split("--", 1)[0] for l in _sql(name, **params).splitlines())  # drop comments first
    for stmt in text.split(";"):
        if stmt.strip():
            con.execute(stmt)


def hour_range(con) -> tuple[int, int]:
    return con.execute("SELECT min(hour), max(hour) FROM pageviews").fetchone()


def build(con: duckdb.DuckDBPyConnection, t_min: int | None = None, t_max: int | None = None) -> pd.DataFrame:
    """Create SURGE_HOURS / pv_labels / train_frame in ``con`` and return train_frame.

    Default issue range: first hour with a full 7-day baseline at the last usable pageview bucket,
    through the last hour with pageviews.
    """
    h0, h1 = hour_range(con)
    if t_min is None:
        t_min = h0 + C.BURN_IN + 1 + C.PAGEVIEW_LAG + 1
    if t_max is None:
        t_max = h1
    run_sql(con, "labels.sql", k=C.SURGE_K, min_abs=C.SURGE_MIN_ABS, burn_in=C.BURN_IN,
            hour_end=t_max + max(C.HORIZONS))
    run_sql(con, "features.sql", t_min=t_min, t_max=t_max, lag=C.PAGEVIEW_LAG)
    return con.execute("SELECT * FROM train_frame").df()


def connect(path=C.DB_PATH, read_only=True) -> duckdb.DuckDBPyConnection:
    """In-memory working DB holding a copy of the raw tables; derived tables never touch the source file.

    PC1: swap this for a Snowflake session that exposes the same three raw tables.
    """
    con = duckdb.connect()
    con.execute(f"ATTACH '{path}' AS src (READ_ONLY)")
    for t in ("pages", "edits", "pageviews"):
        con.execute(f"CREATE TABLE {t} AS SELECT * FROM src.{t}")
    con.execute("DETACH src")
    return con


def fresh_from_frames(pages: pd.DataFrame, edits: pd.DataFrame, pageviews: pd.DataFrame) -> duckdb.DuckDBPyConnection:
    """In-memory DB holding exactly the given raw tables (used by leak checks and the live job)."""
    con = duckdb.connect()
    for name, df in {"pages": pages, "edits": edits, "pageviews": pageviews}.items():
        con.register("tmp_df", df)
        con.execute(f"CREATE TABLE {name} AS SELECT * FROM tmp_df")
        con.unregister("tmp_df")
    return con


def raw_tables(con) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    return (con.execute("SELECT * FROM pages").df(), con.execute("SELECT * FROM edits").df(),
            con.execute("SELECT * FROM pageviews").df())


def fingerprint(con) -> str:
    """Cheap, order-independent fingerprint of the raw data, written into every results file."""
    stats = con.execute("""
        SELECT (SELECT count(*) FROM pages), (SELECT count(*) FROM edits), (SELECT round(sum(ts), 3) FROM edits),
               (SELECT count(*) FROM edits WHERE is_bot), (SELECT count(*) FROM pageviews),
               (SELECT sum(views) FROM pageviews)""").fetchone()
    return hashlib.sha256(repr(stats).encode()).hexdigest()[:16]


def horizon_frame(frame: pd.DataFrame, k: int) -> pd.DataFrame:
    """Rows for horizon k with the generic per-horizon columns: sbase, log_sbase, y, views, target_hour."""
    import numpy as np
    out = frame.copy()
    out["sbase"] = out[f"sbase_{k}"]
    out["log_sbase"] = np.log1p(out["sbase"])
    out["y"] = out[f"y_{k}"]
    out["views_target"] = out[f"views_{k}"]
    out["horizon"] = k
    out["target_hour"] = out["t"] + k - 1
    return out
