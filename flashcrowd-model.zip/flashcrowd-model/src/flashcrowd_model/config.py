"""Shared constants. Anything that changes a contract here must also change CONTRACTS.md."""
from __future__ import annotations

from pathlib import Path

SEED = 7
EPOCH0 = "2026-09-07T00:00:00Z"   # hour 0; a Monday 00:00 UTC (PC1 overrides from the real extract)

# --- time / availability (CONTRACTS §1)
PAGEVIEW_LAG = 1          # pageviews for bucket h are usable from issue time h + 1 + PAGEVIEW_LAG
HORIZONS = (1, 2, 3)      # horizon k targets bucket t + k - 1
BURN_IN = 168             # hours of history before labels exist

# --- surge definition (CONTRACTS §2)
SURGE_K = 3.0
SURGE_MIN_ABS = 500

# --- region map (language edition -> serving region)
LANG_REGION = {"en": "us-east", "de": "eu-west", "fr": "eu-west", "es": "sa-east", "pt": "sa-east",
               "ja": "ap-northeast"}

# --- splits: fractions of issue hours after burn-in, in time order, with an embargo between them
SPLIT_FRACS = {"train": 0.55, "calib": 0.15, "test": 0.30}
EMBARGO = max(HORIZONS)   # hours dropped between segments so labels never straddle a boundary

# --- model features (anything starting with y_ or views_ is a label and must never be listed)
FEATURES = [
    "e_h1", "e_h3", "e_prev3", "e_accel", "u_h1", "u_h3", "bot_h1", "bot_h3", "bot_share3",
    "langs_h3", "qid_e_h3", "pv_last", "pv_prev", "baseline_7d", "ratio_last", "log_ratio_last",
    "surge_last", "hod", "dow",
]
HORIZON_FEATURES = ["sbase", "log_sbase"]   # per-horizon seasonal baseline for the target hour

REGION_SURGE_MULT = 1.5   # regional surge = demand above 1.5x the sum of seasonal baselines

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
OUT_DIR = ROOT / "out"
DB_PATH = DATA_DIR / "flashcrowd.duckdb"
SQL_DIR = Path(__file__).resolve().parent / "sql"
