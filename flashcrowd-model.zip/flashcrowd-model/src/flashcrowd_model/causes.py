"""Optional cause labels ("why is this page busy?") as extra features. Off by default.

Add these only after the core pipeline works, and keep them only if the on/off comparison
(`flashcrowd-train --causes none` vs `--causes heuristic|gemini`) shows a test-window gain.

Leak rule: a labeler sees ONLY what existed at issue time t (titles plus edit summaries with ts < t).
An LLM can still know how a past event turned out from its own training data, so backtest gains
from Gemini are an UPPER bound unless the model's knowledge cutoff predates the test window.
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd

CAUSES = ("breaking_news", "edit_war", "bot_maintenance", "routine")
CAUSE_COLS = [f"cause_{c}" for c in CAUSES]


class HeuristicLabeler:
    """Rule-based stand-in with the same interface as the Gemini labeler; uses issue-time features only."""
    name = "heuristic"

    def label(self, frame: pd.DataFrame) -> pd.Series:
        news = (frame["u_h3"] >= 4) | (frame["langs_h3"] >= 2)
        war = (frame["e_h3"] >= 10) & (frame["u_h3"] <= 2)
        bot = frame["bot_share3"] >= 0.6
        out = np.select([news, war, bot], ["breaking_news", "edit_war", "bot_maintenance"], "routine")
        return pd.Series(out, index=frame.index)


class GeminiLabeler:
    """Calls Gemini on issue-time text. Needs `pip install .[gemini]`, GEMINI_API_KEY, and an `edit_text` column
    holding concatenated edit summaries with ts < t (PC1 provides it from the raw stream)."""
    name = "gemini"

    def __init__(self, model: str = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")):
        from google import genai  # imported lazily so the core package never depends on it
        self.client = genai.Client()
        self.model = model
        self._cache: dict[str, str] = {}

    def _ask(self, title: str, text: str) -> str:
        key = f"{title}|{text[:500]}"
        if key not in self._cache:
            prompt = (f"Wikipedia page '{title}'. Recent edit summaries: {text[:2000]}\n"
                      f"Classify the reason for the editing activity as exactly one of: {', '.join(CAUSES)}. "
                      "Answer with the label only.")
            r = self.client.models.generate_content(model=self.model, contents=prompt)
            ans = (r.text or "").strip().lower()
            self._cache[key] = ans if ans in CAUSES else "routine"
        return self._cache[key]

    def label(self, frame: pd.DataFrame) -> pd.Series:
        if "edit_text" not in frame.columns:
            raise ValueError("GeminiLabeler needs an 'edit_text' column built from edits with ts < t")
        active = frame["e_h3"] > 0                     # only spend calls on pages with recent edits
        out = pd.Series("routine", index=frame.index)
        for i in frame.index[active]:
            out.at[i] = self._ask(str(frame.at[i, "qid"]), str(frame.at[i, "edit_text"]))
        return out


def get_labeler(name: str):
    return {"none": None, "heuristic": HeuristicLabeler, "gemini": GeminiLabeler}[name]() if name != "none" else None


def add_cause_features(frame: pd.DataFrame, labeler) -> tuple[pd.DataFrame, list[str]]:
    if labeler is None:
        return frame, []
    lab = labeler.label(frame)
    out = frame.copy()
    for c in CAUSES:
        out[f"cause_{c}"] = (lab == c).astype(np.int8)
    return out, CAUSE_COLS
