"""No-look-ahead checks. Training refuses to run unless every check here passes.

The core check is a perturbation test: rewrite everything that is NOT available at a cutoff hour
(edits with ts >= cut, pageview buckets >= cut - PAGEVIEW_LAG) with random values, rebuild features,
and require every feature for issue times <= cut to be bit-for-bit identical. A power check confirms
the rewrite does change features after the cutoff, so a test that compares nothing cannot pass.
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd

from . import config as C
from . import features as F
from .splits import make_splits

CHECK_COLS = C.FEATURES + ["sbase_1", "sbase_2", "sbase_3"]


def _perturb(edits: pd.DataFrame, pv: pd.DataFrame, cut: int, rng: np.random.Generator):
    e = edits.copy()
    late = e["ts"] >= cut
    e.loc[late, "editor"] = [f"ghost{i}" for i in rng.integers(0, 50, late.sum())]
    e.loc[late, "is_bot"] = rng.random(late.sum()) < 0.5
    pages = e[["page_id", "qid", "lang"]].drop_duplicates("page_id")
    extra = pages.sample(n=min(len(pages), 200), replace=True, random_state=int(rng.integers(1e9)))
    extra = extra.assign(ts=cut + rng.random(len(extra)) * 6, editor="flood", is_bot=False)
    e = pd.concat([e, extra[e.columns]], ignore_index=True)
    p = pv.copy()
    hidden = p["hour"] >= cut - C.PAGEVIEW_LAG
    p.loc[hidden, "views"] = rng.integers(0, 50_000, hidden.sum())
    return e, p


def perturbation_check(pages, edits, pv, cut: int, seed: int = 0, window: int = 30) -> dict:
    rng = np.random.default_rng(seed)
    t_min, t_max = cut - window, cut + 4
    base = F.build(F.fresh_from_frames(pages, edits, pv), t_min, t_max)
    e2, p2 = _perturb(edits, pv, cut, rng)
    pert = F.build(F.fresh_from_frames(pages, e2, p2), t_min, t_max)
    key = ["page_id", "t"]
    m = base.merge(pert, on=key, suffixes=("", "_p"))
    before = m["t"] <= cut
    diffs = {}
    for c in CHECK_COLS:
        a, b = m.loc[before, c].to_numpy(float), m.loc[before, c + "_p"].to_numpy(float)
        n = int((~((a == b) | (np.isnan(a) & np.isnan(b)))).sum())
        if n:
            diffs[c] = n
    after = ~before
    power = int(sum((m.loc[after, c].fillna(-1) != m.loc[after, c + "_p"].fillna(-1)).sum() for c in CHECK_COLS))
    return {"check": f"perturbation@{cut}", "passed": not diffs and power > 0, "leaking_columns": diffs,
            "rows_compared": int(before.sum()), "changed_after_cut": power}


def schema_check(frame: pd.DataFrame) -> dict:
    bad = [c for c in C.FEATURES + C.HORIZON_FEATURES if c.startswith(("y_", "views_")) or c in ("y", "views_target")]
    missing = [c for c in C.FEATURES if c not in frame.columns]
    return {"check": "schema", "passed": not bad and not missing, "label_named_features": bad, "missing": missing}


def split_check(frame: pd.DataFrame) -> dict:
    s = make_splits(frame["t"])
    gaps = []
    for a, b in (("train", "calib"), ("calib", "test")):
        last_label_hour = s[a][1] + max(C.HORIZONS) - 1
        first_feature_hour = s[b][0]
        if last_label_hour >= first_feature_hour:
            gaps.append(f"{a} labels reach hour {last_label_hour} >= {b} starts {first_feature_hour}")
    return {"check": "split_embargo", "passed": not gaps, "splits": s, "problems": gaps}


def run_all(con, n_cuts: int = 3, seed: int = C.SEED) -> dict:
    pages, edits, pv = F.raw_tables(con)
    frame = F.build(con)
    h0, h1 = F.hour_range(con)
    rng = np.random.default_rng(seed)
    lo = h0 + C.BURN_IN + 40
    cuts = sorted(int(c) for c in rng.integers(lo, h1 - 10, n_cuts))
    checks = [schema_check(frame), split_check(frame)]
    checks += [perturbation_check(pages, edits, pv, c, seed=seed + i) for i, c in enumerate(cuts)]
    report = {"passed": all(c["passed"] for c in checks), "data_fingerprint": F.fingerprint(con), "checks": checks}
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description="Run no-look-ahead leak checks")
    ap.add_argument("--cuts", type=int, default=3)
    a = ap.parse_args(argv)
    con = F.connect()
    rep = run_all(con, a.cuts)
    C.OUT_DIR.mkdir(exist_ok=True)
    (C.OUT_DIR / "leakcheck.json").write_text(json.dumps(rep, indent=2, default=str))
    for c in rep["checks"]:
        print(("PASS " if c["passed"] else "FAIL ") + c["check"])
    print("ALL PASSED" if rep["passed"] else "LEAK CHECKS FAILED: do not train or report results")
    raise SystemExit(0 if rep["passed"] else 1)


if __name__ == "__main__":
    main()
