"""Time-ordered splits with an embargo so a label window never straddles two segments."""
from __future__ import annotations

import numpy as np

from . import config as C


def make_splits(t_values, fracs=C.SPLIT_FRACS, embargo=C.EMBARGO) -> dict[str, tuple[int, int]]:
    """Inclusive (start, end) issue-hour ranges for train / calib / test."""
    ts = np.unique(np.asarray(t_values))
    n = len(ts)
    a = int(n * fracs["train"])
    b = int(n * (fracs["train"] + fracs["calib"]))
    return {
        "train": (int(ts[0]), int(ts[a - 1])),
        "calib": (int(ts[a - 1]) + embargo + 1, int(ts[b - 1])),
        "test": (int(ts[b - 1]) + embargo + 1, int(ts[-1])),
    }


def walk_forward(t_values, n_folds=3, min_train_frac=0.4, embargo=C.EMBARGO):
    """Expanding-window folds: yield (train_range, valid_range), each valid block after its train block."""
    ts = np.unique(np.asarray(t_values))
    start = int(len(ts) * min_train_frac)
    edges = np.linspace(start, len(ts), n_folds + 1).astype(int)
    for i in range(n_folds):
        tr_end = ts[edges[i] - 1]
        va = ts[edges[i]: edges[i + 1]]
        va = va[va > tr_end + embargo]
        if len(va):
            yield (int(ts[0]), int(tr_end)), (int(va[0]), int(va[-1]))


def mask(frame, rng: tuple[int, int]):
    return (frame["t"] >= rng[0]) & (frame["t"] <= rng[1])
