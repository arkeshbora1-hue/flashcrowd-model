"""Backtest the full decision system on held-out data and produce the pitch numbers + charts.

Fairness rules (CONTRACTS + plan review):
  * every policy family sweeps its OWN knob; the operating point is chosen on the CALIB window
    and reported on the TEST window, for each cost weight
  * forecasts come from the same forecast_job code the live system runs
  * oracle is shown as a ceiling, never as a claim
"""
from __future__ import annotations

import argparse
import json
import math

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from flashcrowd_engine import ForecastStore, SimConfig, Simulator
from flashcrowd_engine.decision import service_level
from flashcrowd_engine.grading import grade, lead_time, pareto_front
from flashcrowd_engine.policies import AutopilotPolicy, OraclePolicy, ReactivePolicy, StaticPolicy

from . import config as C
from . import features as F
from .forecast_job import batch, write
from .model import ForecastModel

CAP = 2500.0
BASE_PENALTY = 0.95 / 0.05 * (1.0 / CAP)    # default weight: newsvendor service level 0.95
WEIGHTS = (0.25, 0.5, 1.0, 2.0, 4.0)         # multipliers on the unserved-view penalty
SIM = SimConfig(capacity_per_server=CAP, boot_steps=1, min_servers=2, max_servers=250,
                max_scale_up_per_step=40, cost_per_server_step=1.0, penalty_per_unserved=BASE_PENALTY)
KNOBS = {
    "reactive": [0.0, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0],
    "autopilot": [0.5, 0.7, 0.8, 0.9, 0.95, 0.97, 0.99, 0.995],
    "static": [0.5, 0.75, 0.9, 0.95, 0.99, 1.0],      # quantile of TRAIN-window regional demand
}


def region_demand(con) -> pd.DataFrame:
    return con.execute("""SELECT p.region, v.hour, sum(v.views)::DOUBLE AS demand
                          FROM pageviews v JOIN pages p USING (page_id) GROUP BY ALL ORDER BY 1, 2""").df()


def run_family(family, knob, window, dem, stores, train_q, sim=Simulator(SIM)):
    """Sum of grades over regions for one policy setting on one window."""
    lo, hi = window
    totals, frames = None, {}
    for region, g in dem.groupby("region"):
        g = g.set_index("hour")["demand"]
        d = g.loc[lo:hi].to_numpy()
        hist = g.loc[lo - 24: lo - 1].to_numpy()
        if family == "reactive":
            pol = ReactivePolicy(knob)
        elif family == "autopilot":
            pol = AutopilotPolicy(knob)
        elif family == "static":
            pol = StaticPolicy(math.ceil(train_q[region][knob] / CAP))
        else:
            pol = OraclePolicy(d, lo)
        res = sim.run(d, pol, stores.get(region), start_hour=lo, history=hist)
        frames[region] = res.frame
        g_ = grade(res)
        g_["unserved_units"] = float(res.frame["unserved"].sum())
        g_["demand_units"] = float(res.frame["demand"].sum())
        if totals is None:
            totals = {k: v for k, v in g_.items() if not isinstance(v, str)}
        else:
            for k, v in g_.items():
                if not isinstance(v, str):
                    totals[k] += v
    totals["unserved_frac"] = totals["unserved_units"] / totals["demand_units"]
    totals["false_launch_rate"] = totals["false_launch_events"] / max(1, totals["launch_events"])
    totals.update(family=family, knob=knob)
    return totals, frames


def cost_at(row, w):
    return row["server_cost"] + w * BASE_PENALTY * row["unserved_units"]


def pick_replay_levels(dem: pd.DataFrame, window, n=3, half=6):
    lo, hi = window
    cands = []
    for region, g in dem.groupby("region"):
        s = g.set_index("hour")["demand"]
        base = s.rolling(168, min_periods=24).median().shift(1)
        r = (s / base).loc[lo + half: hi - half]
        for h, v in r.sort_values(ascending=False).items():
            cands.append((float(v), region, int(h), float(s.loc[h])))
    cands.sort(reverse=True)
    picked = []
    for ratio, region, h, peak in cands:
        if all(abs(h - p["peak_hour"]) > 2 * half or region != p["region"] for p in picked):
            picked.append({"level_id": f"L{len(picked) + 1}", "region": region, "start_hour": h - half,
                           "end_hour": h + half, "peak_hour": h, "peak_views": round(peak),
                           "note": f"peak {ratio:.1f}x trailing 7-day median, held-out test window"})
        if len(picked) == n:
            break
    return picked


def main(argv=None):
    ap = argparse.ArgumentParser(description="Backtest FLASHCROWD on held-out data")
    ap.add_argument("--model", default=str(C.MODEL_DIR / "forecast_model.pkl"))
    ap.add_argument("--suffix", default="", help="appended to output names, e.g. _heuristic for Gemini on/off runs")
    a = ap.parse_args(argv)
    con = F.connect()
    model = ForecastModel.load(__import__("pathlib").Path(a.model))
    if model.meta["data_fingerprint"] != F.fingerprint(con):
        raise RuntimeError("model was trained on different data; retrain first")
    sp = model.meta["splits"]
    calib, test = tuple(sp["calib"]), tuple(sp["test"])

    frame = F.build(con)
    art, reg = batch(con, model, calib[0], test[1], frame=frame)
    write(art, reg, "backtest")
    stores = {r: ForecastStore.from_frame(reg, r) for r in reg["region"].unique()}
    dem = region_demand(con)
    train_q = {r: {q: float(g.loc[g["hour"].between(*sp["train"]), "demand"].quantile(q)) for q in KNOBS["static"]}
               for r, g in dem.groupby("region")}

    # ---- sweep every knob on both windows (sim outcome does not depend on the cost weight)
    rows, frames = [], {}
    for window_name, window in (("calib", calib), ("test", test)):
        for fam, knobs in KNOBS.items():
            for kb in knobs:
                tot, fr = run_family(fam, kb, window, dem, stores, train_q)
                tot["window"] = window_name
                rows.append(tot)
                frames[(window_name, fam, kb)] = fr
        tot, fr = run_family("oracle", None, window, dem, stores, train_q)
        tot["window"] = window_name
        rows.append(tot)
        frames[(window_name, "oracle", None)] = fr
    sweep = pd.DataFrame(rows)

    # ---- per cost weight: choose knob on calib, report on test
    weight_table, chosen = [], {}
    for w in WEIGHTS:
        rec = {"weight": w, "service_level": service_level(1.0, CAP, BASE_PENALTY * w)}
        for fam in ("static", "reactive", "autopilot"):
            cal = sweep[(sweep.window == "calib") & (sweep.family == fam)]
            kb = cal.loc[cal.apply(cost_at, axis=1, w=w).idxmin(), "knob"]
            tst = sweep[(sweep.window == "test") & (sweep.family == fam) & (sweep.knob == kb)].iloc[0]
            rec[f"{fam}_knob"] = kb
            rec[f"{fam}_cost"] = cost_at(tst, w)
            chosen[(w, fam)] = tst
        orc = sweep[(sweep.window == "test") & (sweep.family == "oracle")].iloc[0]
        rec["oracle_cost"] = cost_at(orc, w)
        rec["autopilot_saving_vs_reactive"] = 1 - rec["autopilot_cost"] / rec["reactive_cost"]
        weight_table.append(rec)
    weight_df = pd.DataFrame(weight_table)

    # ---- headline at the default weight
    head = {}
    for fam in ("static", "reactive", "autopilot"):
        r = chosen[(1.0, fam)]
        head[fam] = {k: (float(r[k]) if not isinstance(r[k], str) else r[k]) for k in
                     ("knob", "server_cost", "unserved_frac", "sla_breach_hours", "idle_server_hours",
                      "launch_events", "false_launch_events", "false_launch_rate")}
        head[fam]["total_cost"] = cost_at(r, 1.0)
    orc = sweep[(sweep.window == "test") & (sweep.family == "oracle")].iloc[0]
    head["oracle"] = {"total_cost": cost_at(orc, 1.0), "unserved_frac": float(orc["unserved_frac"]),
                      "server_cost": float(orc["server_cost"])}

    # ---- forecast quality: lead time on article surges in the test window
    onsets = con.execute("SELECT * FROM SURGE_ONSETS").df()
    onsets = onsets[onsets["hour"].between(test[0] + 2, test[1])]
    art_test = art[art["issued_at"].between(*test)]
    art_cal = art[art["issued_at"].between(*calib)]
    lab = frame[["page_id", "t", "y_1", "y_2", "y_3"]]
    thr_grid = np.linspace(0.1, 0.9, 17)
    f1 = []
    for thr in thr_grid:    # threshold chosen on calib
        m = art_cal.merge(lab, left_on=["page_id", "issued_at"], right_on=["page_id", "t"])
        y = np.select([m.horizon == 1, m.horizon == 2], [m.y_1, m.y_2], m.y_3)
        ok = ~np.isnan(y.astype(float))
        pred, yy = (m.p_surge[ok] >= thr).to_numpy(), y[ok].astype(int)
        tp = (pred & (yy == 1)).sum()
        f1.append(2 * tp / max(1, pred.sum() + yy.sum()))
    thr = float(thr_grid[int(np.argmax(f1))])
    lt = lead_time(art_test, onsets, thr, SIM.boot_steps)
    lt["threshold"] = thr

    # ---- charts
    C.OUT_DIR.mkdir(exist_ok=True)
    colors = {"static": "#8c8c8c", "reactive": "#d1495b", "autopilot": "#2e86ab", "oracle": "#222222"}
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    tst = sweep[sweep.window == "test"]
    for fam in ("static", "reactive", "autopilot"):
        s = tst[tst.family == fam].sort_values("server_cost")
        ax.plot(s.server_cost, 100 * s.unserved_frac, "-o", ms=4, color=colors[fam], label=fam, alpha=0.9)
        c = chosen[(1.0, fam)]
        ax.plot(c.server_cost, 100 * c.unserved_frac, "*", ms=16, color=colors[fam], mec="white")
    o = tst[tst.family == "oracle"].iloc[0]
    ax.plot(o.server_cost, 100 * o.unserved_frac, "D", color=colors["oracle"], label="oracle (ceiling)")
    ax.set_xlabel("Server cost (server-hours, test window)")
    ax.set_ylabel("Unserved demand (%)")
    ax.set_yscale("symlog", linthresh=0.1)
    ax.set_title("Autopilot reaches lower unserved demand per server-hour\n(stars = setting chosen on calib window)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(C.OUT_DIR / f"pareto{a.suffix}.png", dpi=160)
    plt.close(fig)

    levels = pick_replay_levels(dem, test)
    (C.OUT_DIR / "replay_levels.json").write_text(json.dumps(levels, indent=2))
    if levels:
        L = levels[0]
        fig, ax = plt.subplots(figsize=(7.5, 4.0))
        for fam, lab_ in (("reactive", "reactive"), ("autopilot", "autopilot")):
            kb = chosen[(1.0, fam)]["knob"]
            fr = frames[("test", fam, kb)][L["region"]]
            fr = fr[fr.hour.between(L["start_hour"] - 6, L["end_hour"] + 6)]
            ax.step(fr.hour, fr.capacity, where="post", color=colors[fam], label=f"{lab_} capacity")
        ax.step(fr.hour, fr.demand, where="post", color="black", lw=2, label="demand")
        ax.set_xlabel("hour")
        ax.set_ylabel("views / hour")
        ax.set_title(f"Replay {L['level_id']} ({L['region']}): capacity vs demand, hour buckets")
        ax.legend(frameon=False)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(C.OUT_DIR / f"replay_{L['level_id']}.png", dpi=160)
        plt.close(fig)

    results = {
        "data_fingerprint": F.fingerprint(con), "seed": C.SEED, "model_version": model.version,
        "windows": {"calib": calib, "test": test}, "sim_config": SIM.__dict__,
        "headline_default_weight": head, "cost_weight_sweep": weight_df.to_dict("records"),
        "lead_time": lt, "replay_levels": levels,
    }
    (C.OUT_DIR / f"results{a.suffix}.json").write_text(json.dumps(results, indent=2, default=float))
    sweep.to_csv(C.OUT_DIR / f"sweep{a.suffix}.csv", index=False)
    pareto_front(tst[tst.family == "autopilot"]).to_csv(C.OUT_DIR / "pareto_autopilot.csv", index=False)

    r, ap_ = head["reactive"], head["autopilot"]
    print(f"TEST, default weight: autopilot cost {ap_['total_cost']:.0f} vs reactive {r['total_cost']:.0f} "
          f"({1 - ap_['total_cost'] / r['total_cost']:+.1%} saving) | unserved {ap_['unserved_frac']:.2%} vs "
          f"{r['unserved_frac']:.2%} | false launches {ap_['false_launch_rate']:.0%} vs {r['false_launch_rate']:.0%}")
    print(weight_df.round(3).to_string(index=False))
    print("lead time:", {k: round(v, 3) for k, v in lt.items()})
    print("replay levels:", [(l["level_id"], l["region"], l["peak_hour"]) for l in levels])


if __name__ == "__main__":
    main()
