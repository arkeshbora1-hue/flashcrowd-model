-- Decision grid + issue-time features + labels. Run after labels.sql.
-- Params: {t_min}, {t_max} issue hours; {lag} pageview publication lag (hours).
-- Availability at issue time t:  edits with ts < t  (edit buckets <= t-1)
--                                pageviews for buckets <= t-1-{lag}
-- Every feature below is computed at a "last usable bucket" and joined to t by that offset.

-- 1. hourly edit buckets per page (human vs bot kept apart; distinct human editors as a list)
CREATE OR REPLACE TABLE edit_hours AS
SELECT page_id, CAST(floor(ts) AS INTEGER) AS hour,
       count(*) FILTER (WHERE NOT is_bot)              AS n_human,
       count(*) FILTER (WHERE is_bot)                  AS n_bot,
       list(DISTINCT editor) FILTER (WHERE NOT is_bot) AS editors
FROM edits
GROUP BY ALL;

CREATE OR REPLACE TABLE qid_lang_hours AS
SELECT qid, CAST(floor(ts) AS INTEGER) AS hour,
       list(DISTINCT lang) FILTER (WHERE NOT is_bot) AS langs,
       count(*) FILTER (WHERE NOT is_bot)            AS n_human
FROM edits
GROUP BY ALL;

-- 2. dense windows over edit buckets, keyed by the LAST bucket h they include
CREATE OR REPLACE TABLE edit_feats AS
WITH dense AS (
    SELECT p.page_id, h.hour,
           COALESCE(e.n_human, 0) AS n_human, COALESCE(e.n_bot, 0) AS n_bot,
           COALESCE(e.editors, []::VARCHAR[]) AS editors
    FROM pages p
    CROSS JOIN (SELECT range AS hour FROM range({t_min} - 7, {t_max})) h
    LEFT JOIN edit_hours e ON e.page_id = p.page_id AND e.hour = h.hour
)
SELECT page_id, hour,
       n_human AS e_h1,
       sum(n_human) OVER w3 AS e_h3,
       sum(n_human) OVER (PARTITION BY page_id ORDER BY hour ROWS BETWEEN 5 PRECEDING AND 3 PRECEDING) AS e_prev3,
       len(editors) AS u_h1,
       len(list_distinct(flatten(list(editors) OVER w3))) AS u_h3,
       n_bot AS bot_h1,
       sum(n_bot) OVER w3 AS bot_h3
FROM dense
WINDOW w3 AS (PARTITION BY page_id ORDER BY hour ROWS BETWEEN 2 PRECEDING AND CURRENT ROW);

CREATE OR REPLACE TABLE qid_feats AS
WITH dense AS (
    SELECT q.qid, h.hour, COALESCE(e.langs, []::VARCHAR[]) AS langs, COALESCE(e.n_human, 0) AS n_human
    FROM (SELECT DISTINCT qid FROM pages) q
    CROSS JOIN (SELECT range AS hour FROM range({t_min} - 7, {t_max})) h
    LEFT JOIN qid_lang_hours e ON e.qid = q.qid AND e.hour = h.hour
)
SELECT qid, hour,
       len(list_distinct(flatten(list(langs) OVER w3))) AS langs_h3,
       sum(n_human) OVER w3 AS qid_e_h3
FROM dense
WINDOW w3 AS (PARTITION BY qid ORDER BY hour ROWS BETWEEN 2 PRECEDING AND CURRENT ROW);

-- 3. the grid with features (edits at bucket t-1, pageviews at bucket t-1-lag) and labels per horizon
CREATE OR REPLACE TABLE train_frame AS
SELECT
    g.page_id, p.qid, p.lang, p.region, g.t,
    ef.e_h1, ef.e_h3, COALESCE(ef.e_prev3, 0) AS e_prev3, ef.e_h3 - COALESCE(ef.e_prev3, 0) AS e_accel,
    ef.u_h1, ef.u_h3, ef.bot_h1, ef.bot_h3,
    ef.bot_h3 / (ef.bot_h3 + ef.e_h3 + 1.0) AS bot_share3,
    qf.langs_h3, qf.qid_e_h3,
    pl.views AS pv_last, pp.views AS pv_prev, pl.baseline_7d,
    pl.views / (pl.baseline_7d + 1.0) AS ratio_last,
    ln((pl.views + 1.0) / (pl.baseline_7d + 1.0)) AS log_ratio_last,
    CAST(COALESCE(pl.surge, FALSE) AS INTEGER) AS surge_last,
    g.t % 24 AS hod, (g.t // 24) % 7 AS dow,
    s1.seasonal_base AS sbase_1, s2.seasonal_base AS sbase_2, s3.seasonal_base AS sbase_3,
    CAST(s1.surge AS INTEGER) AS y_1, CAST(s2.surge AS INTEGER) AS y_2, CAST(s3.surge AS INTEGER) AS y_3,
    s1.views AS views_1, s2.views AS views_2, s3.views AS views_3
FROM (SELECT page_id, range AS t FROM pages CROSS JOIN range({t_min}, {t_max} + 1)) g
JOIN pages p USING (page_id)
JOIN edit_feats ef ON ef.page_id = g.page_id AND ef.hour = g.t - 1
JOIN qid_feats  qf ON qf.qid = p.qid AND qf.hour = g.t - 1
LEFT JOIN pv_labels pl ON pl.page_id = g.page_id AND pl.hour = g.t - 1 - {lag}
LEFT JOIN pv_labels pp ON pp.page_id = g.page_id AND pp.hour = g.t - 2 - {lag}
LEFT JOIN pv_labels s1 ON s1.page_id = g.page_id AND s1.hour = g.t
LEFT JOIN pv_labels s2 ON s2.page_id = g.page_id AND s2.hour = g.t + 1
LEFT JOIN pv_labels s3 ON s3.page_id = g.page_id AND s3.hour = g.t + 2
ORDER BY g.t, g.page_id;
