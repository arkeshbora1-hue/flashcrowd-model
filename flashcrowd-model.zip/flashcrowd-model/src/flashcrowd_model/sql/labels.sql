-- Surge labels (CONTRACTS.md §2). Portable DuckDB / Snowflake SQL.
-- Params: {k} surge multiple, {min_abs} absolute floor, {burn_in} hours of history required.

-- Dense page x hour grid: hours with no row in pageviews count as 0 views. The grid runs to {hour_end}
-- (past the last observed hour) so seasonal baselines exist for future target hours; views there are NULL.
CREATE OR REPLACE TABLE pv_dense AS
WITH bounds AS (SELECT min(hour) AS h0, max(hour) AS h1 FROM pageviews)
SELECT p.page_id, h.hour,
       CASE WHEN h.hour <= (SELECT h1 FROM bounds) THEN COALESCE(v.views, 0) END AS views
FROM pages p
CROSS JOIN (SELECT range AS hour FROM range((SELECT h0 FROM bounds), {hour_end} + 1)) h
LEFT JOIN pageviews v ON v.page_id = p.page_id AND v.hour = h.hour;

CREATE OR REPLACE TABLE pv_stats AS
SELECT
    page_id, hour, views,
    -- trailing 7 days, EXCLUDING the current hour
    median(views) OVER (PARTITION BY page_id ORDER BY hour ROWS BETWEEN {burn_in} PRECEDING AND 1 PRECEDING) AS baseline_7d,
    count(*)      OVER (PARTITION BY page_id ORDER BY hour ROWS BETWEEN {burn_in} PRECEDING AND 1 PRECEDING) AS n_hist,
    -- same hour of day on the previous 7 days (seasonal baseline; uses only hours <= hour - 24)
    median(views) OVER (PARTITION BY page_id, hour % 24 ORDER BY hour ROWS BETWEEN 7 PRECEDING AND 1 PRECEDING) AS seasonal_base
FROM pv_dense;

CREATE OR REPLACE TABLE pv_labels AS
SELECT *,
    CASE WHEN n_hist < {burn_in} OR views IS NULL THEN NULL
         ELSE views >= greatest({k} * baseline_7d, baseline_7d + {min_abs}) END AS surge
FROM pv_stats;

CREATE OR REPLACE VIEW SURGE_HOURS AS
SELECT page_id, hour, views, baseline_7d
FROM pv_labels
WHERE surge;

-- Onsets: first hour of each surge run (used for lead-time scoring and replay picking)
CREATE OR REPLACE VIEW SURGE_ONSETS AS
SELECT page_id, hour
FROM (SELECT page_id, hour, surge,
             lag(surge) OVER (PARTITION BY page_id ORDER BY hour) AS prev_surge
      FROM pv_labels)
WHERE surge AND NOT COALESCE(prev_surge, FALSE);
